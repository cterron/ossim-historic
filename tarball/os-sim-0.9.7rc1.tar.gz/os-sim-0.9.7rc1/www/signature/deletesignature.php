<?php
require_once ('classes/Session.inc');
Session::logcheck("MenuPolicy", "PolicySignatures");
?>

<html>
<head>
  <title>OSSIM Framework</title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <link rel="stylesheet" type="text/css" href="../style/style.css"/>
</head>
<body>

  <h1>Delete signature group</h1>

<?php 
    if (!$sig_name = mysql_escape_string($_GET["signame"])) { 
?>
    <p>Wrong signature name</p>
<?php 
        exit;
    }

if (!$_GET["confirm"]) {
?>
    <p>Are you sure?</p>
    <p><a href="<?php echo $_SERVER["PHP_SELF"]."?signame=$sig_name&confirm=yes"; ?>">Yes</a>&nbsp;&nbsp;&nbsp;<a href="signature.php">No</a>
    </p>
<?php
    exit();
}

    require_once 'ossim_db.inc';
    require_once 'classes/Signature_group.inc';
    $db = new ossim_db();
    $conn = $db->connect();
    Signature_group::delete($conn, $sig_name);
    $db->close($conn);

?>

    <p>Signature group deleted</p>
    <p><a href="signature.php">Back</a></p>
    <?php exit(); ?>

</body>
</html>

