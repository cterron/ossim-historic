#!/bin/sh
updatedb --localpaths=/var/ossim/logs --output=/var/ossim/logs/locate.index
