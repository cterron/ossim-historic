<?php
/*****************************************************************************
*
*    License:
*
*   Copyright (c) 2003-2006 ossim.net
*   Copyright (c) 2007-2009 AlienVault
*   All rights reserved.
*
*   This package is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; version 2 dated June, 1991.
*   You may not use, modify or distribute this program under any other version
*   of the GNU General Public License.
*
*   This package is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this package; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston,
*   MA  02110-1301  USA
*
*
* On Debian GNU/Linux systems, the complete text of the GNU General
* Public License can be found in `/usr/share/common-licenses/GPL-2'.
*
* Otherwise you can read it here: http://www.gnu.org/licenses/gpl-2.0.txt
****************************************************************************/
/**
* Class and Function List:
* Function list:
* Classes list:
*/
require_once ('classes/Session.inc');
Session::logcheck("MenuEvents", "EventsAnomalies");
?>

<html>
<head>
  <title> <?php
echo gettext("OSSIM Framework"); ?> </title>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
  <META HTTP-EQUIV="Pragma" CONTENT="no-cache">
  <link rel="stylesheet" type="text/css" href="../style/style.css"/>
</head>
<body>
                                                                                
  <h1> <?php
echo gettext("OSSIM Framework"); ?> </h1>

<?php
require_once 'ossim_db.inc';
require_once 'classes/RRD_anomaly.inc';
require_once 'classes/RRD_anomaly_global.inc';
?>

<?php
$db = new ossim_db();
$conn = $db->connect();
while (list($key, $val) = each($_GET)) {
    list($action, $ip, $what) = split(",", $key, 3);
    $what = ereg_replace("_", " ", $what);
    $what = ereg_replace("rrd anomaly", "rrd_anomaly", $what);
    if ($ip == "Global") {
        switch ($action) {
            case 'ack':
                RRD_anomaly_global::ack($conn, $what);
                break;

            case 'del':
                RRD_anomaly_global::delete($conn, $what);
                break;
        }
    } else {
        $ip = ereg_replace("_", ".", $ip);
        switch ($action) {
            case 'ack':
                RRD_anomaly::ack($conn, $ip, $what);
                break;

            case 'del':
                RRD_anomaly::delete($conn, $ip, $what);
                break;
        }
    }
}
$db->close($conn);
?>
    <p> <?php
echo gettext("Successfully Acked/Deleted"); ?> </p>
<?php
$location = "anomalies.php";
sleep(2);
echo "<script>
///history.go(-1);
window.location='$location';
</script>
";
?>
</body>
</html>

