# $Id: __init__.py,v 1.10 2009/07/06 08:59:16 dkarg Exp $
__version__ = "2.1"
__date__    = "$Date: 2009/07/06 08:59:16 $"
