# $Id: __init__.py,v 1.6 2008/02/19 11:27:07 dvgil Exp $
__version__ = "0.9.9"
__date__    = "$Date: 2008/02/19 11:27:07 $"
