<?php
header('Location: ./bp_list.php');
?>
