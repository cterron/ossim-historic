/* Copyright (c) 2003 ossim.net
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission
 *    from the author.
 *
 * 4. Products derived from this software may not be called "Os-sim" nor
 *    may "Os-sim" appear in their names without specific prior written
 *    permission from the author.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef __SIM_PLUGIN_H__
#define __SIM_PLUGIN_H__ 1

#include <glib.h>
#include <glib-object.h>
#include <libgda/libgda.h>

#include "sim-enums.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SIM_TYPE_PLUGIN                  (sim_plugin_get_type ())
#define SIM_PLUGIN(obj)                  (G_TYPE_CHECK_INSTANCE_CAST (obj, SIM_TYPE_PLUGIN, SimPlugin))
#define SIM_PLUGIN_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST (klass, SIM_TYPE_PLUGIN, SimPluginClass))
#define SIM_IS_PLUGIN(obj)               (G_TYPE_CHECK_INSTANCE_TYPE (obj, SIM_TYPE_PLUGIN))
#define SIM_IS_PLUGIN_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), SIM_TYPE_PLUGIN))
#define SIM_PLUGIN_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), SIM_TYPE_PLUGIN, SimPluginClass))

G_BEGIN_DECLS

typedef struct _SimPlugin         SimPlugin;
typedef struct _SimPluginClass    SimPluginClass;
typedef struct _SimPluginPrivate  SimPluginPrivate;

struct _SimPlugin {
  GObject parent;

  SimPluginType      type;

  SimPluginPrivate  *_priv;
};

struct _SimPluginClass {
  GObjectClass parent_class;
};

GType               sim_plugin_get_type                        (void);
SimPlugin*          sim_plugin_new                             (void);
SimPlugin*          sim_plugin_new_from_dm                     (GdaDataModel  *dm,
																																gint           row);
SimPlugin*          sim_plugin_clone                           (SimPlugin     *plugin);

gint                sim_plugin_get_id                          (SimPlugin     *plugin);
void                sim_plugin_set_id                          (SimPlugin     *plugin,
																																gint           id);
gchar*              sim_plugin_get_name                        (SimPlugin     *plugin);
void                sim_plugin_set_name                        (SimPlugin     *plugin,
																																gchar         *name);
gchar*              sim_plugin_get_description                 (SimPlugin     *plugin);
void                sim_plugin_set_description                 (SimPlugin     *plugin,
																																gchar         *description);
void								sim_plugin_set_sim_type											(SimPlugin      *plugin,
																				                         SimPluginType  type);
SimPluginType				sim_plugin_get_sim_type											(SimPlugin      *plugin);
	
G_END_DECLS

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __SIM_PLUGIN_H__ */
// vim: set tabstop=2:
