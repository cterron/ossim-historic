# $Id: __init__.py,v 1.5 2007/03/14 15:35:31 dvgil Exp $
__version__ = "0.9.9rc4"
__date__    = "$Date: 2007/03/14 15:35:31 $"
