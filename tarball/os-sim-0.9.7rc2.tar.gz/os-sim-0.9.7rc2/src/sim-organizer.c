/* Copyright (c) 2003 ossim.net
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission
 *    from the author.
 *
 * 4. Products derived from this software may not be called "Os-sim" nor
 *    may "Os-sim" appear in their names without specific prior written
 *    permission from the author.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <config.h>

#include "os-sim.h"
#include "sim-organizer.h"
#include "sim-server.h"
#include "sim-host.h"
#include "sim-net.h"
#include "sim-category.h"
#include "sim-plugin-sid.h"
#include "sim-policy.h"
#include "sim-rule.h"
#include "sim-directive-group.h"
#include "sim-directive.h"
#include "sim-host-level.h"
#include "sim-net-level.h"

#include <math.h>
#include <time.h>

extern SimMain  ossim;

enum 
{
  DESTROY,
  LAST_SIGNAL
};

struct _SimOrganizerPrivate {
  SimConfig	*config;
};

static gpointer parent_class = NULL;
static gint sim_container_signals[LAST_SIGNAL] = { 0 };


void
config_send_notify_email (SimConfig	*config,
			  SimAlert	*alert);
void
insert_alert_alarm (SimAlert	*alert);

/* GType Functions */

static void 
sim_organizer_impl_dispose (GObject  *gobject)
{
  G_OBJECT_CLASS (parent_class)->dispose (gobject);
}

static void 
sim_organizer_impl_finalize (GObject  *gobject)
{
  SimOrganizer *organizer = SIM_ORGANIZER (gobject);

  g_free (organizer->_priv);

  G_OBJECT_CLASS (parent_class)->finalize (gobject);
}

static void
sim_organizer_class_init (SimOrganizerClass * class)
{
  GObjectClass *object_class = G_OBJECT_CLASS (class);

  parent_class = g_type_class_peek_parent (class);

  object_class->dispose = sim_organizer_impl_dispose;
  object_class->finalize = sim_organizer_impl_finalize;
}

static void
sim_organizer_instance_init (SimOrganizer *organizer)
{
  organizer->_priv = g_new0 (SimOrganizerPrivate, 1);

  organizer->_priv->config = NULL;
}

/* Public Methods */

GType
sim_organizer_get_type (void)
{
  static GType object_type = 0;
 
  if (!object_type)
  {
    static const GTypeInfo type_info = {
              sizeof (SimOrganizerClass),
              NULL,
              NULL,
              (GClassInitFunc) sim_organizer_class_init,
              NULL,
              NULL,                       /* class data */
              sizeof (SimOrganizer),

              0,                          /* number of pre-allocs */
              (GInstanceInitFunc) sim_organizer_instance_init,
              NULL                        /* value table */
    };
    
    g_type_init ();
                                                                                                                             
    object_type = g_type_register_static (G_TYPE_OBJECT, "SimOrganizer", &type_info, 0);
  }
                                                                                                                             
  return object_type;
}

/*
 *
 *
 *
 *
 */
SimOrganizer*
sim_organizer_new (SimConfig	*config)
{
  SimOrganizer *organizer = NULL;

  g_return_val_if_fail (config, NULL);
  g_return_val_if_fail (SIM_IS_CONFIG (config), NULL);

  organizer = SIM_ORGANIZER (g_object_new (SIM_TYPE_ORGANIZER, NULL));
  organizer->_priv->config = config;

  return organizer;
}



/*
 *
 *
 *
 */
void
sim_organizer_run (SimOrganizer *organizer)
{
  SimAlert *alert = NULL;
  SimCommand *cmd = NULL;
  gchar    *query;
  gchar		*str;

  g_return_if_fail (organizer != NULL);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));

  while (TRUE) 
    {
      alert =  sim_container_pop_alert (ossim.container);
      
      if (!alert)
	{
	  continue;
	}

      if (alert->type == SIM_ALERT_TYPE_NONE)
	{
	  g_object_unref (alert);
	  continue;
	}

      sim_organizer_correlation_plugin (organizer, alert);
      sim_organizer_calificate (organizer, alert);
      sim_organizer_snort (organizer, alert);
      sim_organizer_rrd (organizer, alert);
      insert_alert_alarm (alert);
      sim_organizer_correlation (organizer, alert);

      config_send_notify_email (organizer->_priv->config, alert);

      str = sim_alert_to_string (alert);
      g_message ("sim_organizer_run: %s", str);
      g_free (str);

      if (alert->alarm) {
	cmd = sim_command_new ();
	cmd->type = SIM_COMMAND_TYPE_ALERT;
	cmd->data.alert.alert = alert;
	sim_server_push_session_command (ossim.server, SIM_SESSION_TYPE_RSERVER, cmd);
	g_object_unref (cmd);
      }

      g_object_unref (alert);
    }
}

/*
 *
 *
 *
 *
 */
void
insert_alert_alarm (SimAlert	*alert)
{
  GdaDataModel	*dm;
  GdaValue	*value;
  guint		backlog_id = 0;
  gint		row;
  gchar		*query0;
  gchar		*query1;

  if (!alert->alarm)
    return;

  if (!alert->id)
    sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, alert);
  else
    sim_container_db_update_alert_ul (ossim.container, ossim.dbossim, alert);

  query0 = g_strdup_printf ("SELECT backlog_id, MAX(alert_id) from backlog_alert GROUP BY backlog_id HAVING MAX(alert_id) = %d",
			    alert->id);
  dm = sim_database_execute_single_command (ossim.dbossim, query0);
  if (dm)
    {
      if (!gda_data_model_get_n_rows (dm))
	{
	  if (alert->backlog_id)
	    {
	      query1 = g_strdup_printf ("DELETE FROM alarm WHERE backlog_id = %lu", alert->backlog_id);
	      sim_database_execute_no_query (ossim.dbossim, query1);
	      g_free (query1);
	    }

	  query1 = sim_alert_get_alarm_insert_clause (alert);
	  sim_database_execute_no_query (ossim.dbossim, query1);
	  g_free (query1);
	}

      for (row = 0; row < gda_data_model_get_n_rows (dm); row++)
	{
	  value = (GdaValue *) gda_data_model_get_value_at (dm, 0, row);
	  if (!gda_value_is_null (value))
	    backlog_id = gda_value_get_bigint (value);
	 
	  query1 = g_strdup_printf ("DELETE FROM alarm WHERE backlog_id = %lu", backlog_id);
	  sim_database_execute_no_query (ossim.dbossim, query1);
	  g_free (query1);
	  
	  alert->backlog_id = backlog_id;
	  query1 = sim_alert_get_alarm_insert_clause (alert);
	  sim_database_execute_no_query (ossim.dbossim, query1);
	  g_free (query1);

	}

      g_object_unref(dm);
    }
  else
    {
      g_message ("ORGANIZER ALARM INSERT DATA MODEL ERROR");
    }
  g_free (query0);

  query0 = g_strdup_printf ("SELECT COUNT(backlog_id) FROM alarm WHERE backlog_id != 0 GROUP BY alert_id HAVING COUNT(backlog_id) > 2");
  g_free (query0);
}


/*
 *
 *
 *
 */
void
config_send_notify_email (SimConfig    *config,
			  SimAlert     *alert)
{
  SimAlarmRiskType type = SIM_ALARM_RISK_TYPE_NONE;
  GList     *notifies;
  gint       risk;

  g_return_if_fail (config);
  g_return_if_fail (SIM_IS_CONFIG (config));

  if (!config->notifies)
    return;

  risk = rint (alert->risk_a);
  type = sim_get_alarm_risk_from_risk (risk);

  notifies = config->notifies;
  while (notifies)
    {
      SimConfigNotify *notify = (SimConfigNotify *) notifies->data;

      GList *risks = notify->alarm_risks;
      while (risks)
	{
	  risk = GPOINTER_TO_INT (risks->data);

	  if (risk == SIM_ALARM_RISK_TYPE_ALL || risk == type)
	    {
	      gchar *tmpname;
	      gchar *cmd;
	      gchar *msg;
	      gint   fd;

	      tmpname = g_strdup ("/tmp/ossim-mail.XXXXXX");
	      fd = g_mkstemp (tmpname);
	      
	      msg = g_strdup_printf ("Subject: OSSIM ALARM RISK (%d)\n", risk);
	      write (fd, msg, strlen(msg));
	      g_free (msg);
	      write (fd, "\n", 1);

	      msg = sim_alert_get_msg (alert);
	      write (fd, msg, strlen(msg));
	      g_free (msg);

	      write (fd, ".\n", 2);
	      
	      cmd = g_strdup_printf ("%s %s < %s", config->notify_prog, 
				     notify->emails, tmpname);
	      system (cmd);
	      g_free (cmd);
	      
	      close (fd);
	      unlink(tmpname);
	      g_free (tmpname);
	    }

	  risks = risks->next;
	}
      notifies = notifies->next;
    }
}

/*
 *
 *
 *
 *
 *
 */
void
sim_organizer_correlation_plugin (SimOrganizer *organizer, 
				  SimAlert     *alert)
{
  GList           *list;

  g_return_if_fail (organizer);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));

  if (!alert->dst_ia) return;
  if (alert->rserver) return;

  list = sim_container_db_host_get_plugin_sids_ul (ossim.container,
						   ossim.dbossim,
						   alert->dst_ia,
						   alert->plugin_id,
						   alert->plugin_sid);

  if (!list)
    return;

  while (list)
    {
      SimPluginSid *plugin_sid = (SimPluginSid *) list->data;
      gint  new_priority = sim_plugin_sid_get_priority (plugin_sid);

      alert->priority = (new_priority > alert->priority) ? new_priority : alert->priority;
      alert->reliability += sim_plugin_sid_get_reliability (plugin_sid);

      list = list->next;
    }
  g_list_free (list);

  alert->alarm = TRUE;

  if (alert->priority > 5)
    alert->priority = 5;
  if (alert->reliability > 10)
    alert->reliability = 10;
}

/*
 *
 *
 *
 *
 *
 */
void
sim_organizer_calificate (SimOrganizer *organizer, 
			  SimAlert     *alert)
{
  SimHost         *host;
  SimNet          *net;
  SimCategory     *category = NULL;
  SimPlugin       *plugin;
  SimPluginSid    *plugin_sid;
  SimPolicy       *policy;
  SimHostLevel    *host_level;
  SimNetLevel     *net_level;
  GList           *list;
  GList           *nets;
  gint             threshold = 1;
  gint             asset_net = 1;

  SimPortProtocol *pp;

  gint             date = 0;
  gint             i;
  struct tm       *loctime;
  time_t           curtime;

  g_return_if_fail (organizer != NULL);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));
  g_return_if_fail (alert != NULL);
  g_return_if_fail (SIM_IS_ALERT (alert));

  if (alert->rserver) return;

  /*
   * get current day and current hour
   * calculate date expresion to be able to compare dates
   *
   * for example, Fri 21h = ((5 - 1) * 7) + 21 = 49
   *              Sat 14h = ((6 - 1) * 7) + 14 = 56
   */
  curtime = time (NULL);
  loctime = localtime (&curtime);
  date = ((loctime->tm_wday - 1) * 7) + loctime->tm_hour;

  plugin = sim_container_get_plugin_by_id (ossim.container, alert->plugin_id);
  plugin_sid = sim_container_get_plugin_sid_by_pky (ossim.container, alert->plugin_id, alert->plugin_sid);

  if ((plugin_sid) && (sim_plugin_sid_get_category_id (plugin_sid) > 0))
    {
      category = sim_container_get_category_by_id (ossim.container, sim_plugin_sid_get_category_id (plugin_sid));
      if (category)
	{
	  pp = sim_port_protocol_new (alert->dst_port, alert->protocol);
	  policy = (SimPolicy *) 
	    sim_container_get_policy_match (ossim.container,
					    date,
					    alert->src_ia,
					    alert->dst_ia,
					    pp,
					    sim_category_get_name (category));
	  g_free (pp);
	  
	  if (policy)
	    alert->priority = sim_policy_get_priority (policy);
	}
      else
	g_message ("Category not found: %d, %d", alert->plugin_id, alert->plugin_sid);
    }

  alert->plugin = plugin;
  alert->pluginsid = plugin_sid;

  /* Get the reliability of thr plugin sid */
  if ((alert->reliability == 1) && (alert->plugin_id != SIM_PLUGIN_ID_DIRECTIVE))
    {
      alert->reliability = sim_plugin_sid_get_reliability (plugin_sid);
    }

  alert->asset_src = 2;
  alert->asset_dst = 2;

  if (alert->src_ia)
    {
      /* Source Asset */
      host = sim_container_get_host_by_ia (ossim.container, alert->src_ia);
      nets = sim_container_get_nets_has_ia (ossim.container, alert->src_ia);

      if (host)
	alert->asset_src = sim_host_get_asset (host);
      else if (nets)
	{
	  list = nets;
	  while (list)
	    {
	      net = (SimNet *) list->data;
	      asset_net = sim_net_get_asset (net);
	      if (asset_net > alert->asset_src)
		alert->asset_src = asset_net;

	      list = list->next;
	    }
	}

      alert->risk_c = ((double) (alert->priority * alert->asset_src * alert->reliability)) / 10;
      if (alert->risk_c < 0)
	alert->risk_c = 0;
      else if (alert->risk_c > 10)
	alert->risk_c = 10;
      
      if (alert->risk_c >= 2) {
	alert->alarm = TRUE;
      }

      /* Updates Host Level C */
      host_level = sim_container_get_host_level_by_ia (ossim.container, alert->src_ia);
      if (host_level)
	{
	  sim_host_level_plus_c (host_level, (alert->risk_c / 2.5)); /* Memory update */
	  sim_container_db_update_host_level (ossim.container, ossim.dbossim, host_level); /* DB update */
	}
      else
	{
	  host_level = sim_host_level_new (alert->src_ia, (alert->risk_c / 2.5), 1); /* Create new host_level */
	  sim_container_append_host_level (ossim.container, host_level); /* Memory addition */
	  sim_container_db_insert_host_level (ossim.container, ossim.dbossim, host_level); /* DB insert */
	}
      
      /* Update Net Levels C */
      list = nets;
      while (list)
	{
	  net = (SimNet *) list->data;
	  
	  net_level = sim_container_get_net_level_by_name (ossim.container, sim_net_get_name (net));
	  if (net_level)
	    {
	      sim_net_level_plus_c (net_level, (alert->risk_c / 2.5)); /* Memory update */
	      sim_container_db_update_net_level (ossim.container, ossim.dbossim, net_level); /* DB update */
	    }
	  else
	    {
	      net_level = sim_net_level_new (sim_net_get_name (net), (alert->risk_c / 2.5), 1);
	      sim_container_append_net_level (ossim.container, net_level); /* Memory addition */
	      sim_container_db_insert_net_level (ossim.container, ossim.dbossim, net_level); /* DB insert */
	    }

	  list = list->next;
	}
      g_list_free (nets);
    }

  if (alert->dst_ia)
    {
      /* Destination Asset */
      host = (SimHost *) sim_container_get_host_by_ia (ossim.container, alert->dst_ia);
      nets = sim_container_get_nets_has_ia (ossim.container, alert->dst_ia);

      if (host)
	alert->asset_dst = sim_host_get_asset (host);
      else if (nets)
	{
	  list = nets;
	  while (list)
	    {
	      net = (SimNet *) list->data;
	      asset_net = sim_net_get_asset (net);
	      if (asset_net > alert->asset_dst)
		alert->asset_dst = asset_net;

	      list = list->next;
	    }
	}
      
      alert->risk_a = ((double) (alert->priority * alert->asset_dst * alert->reliability)) / 10;
      if (alert->risk_a < 0)
	alert->risk_a = 0;
      else if (alert->risk_a > 10)
	alert->risk_a = 10;

      /* Threshold */
      threshold = sim_container_db_get_threshold (ossim.container, ossim.dbossim);
      if (alert->risk_a >= 2) {
	alert->alarm = TRUE;
      }

      /* Updates Host Level A */
      host_level = sim_container_get_host_level_by_ia (ossim.container, alert->dst_ia);
      if (host_level)
	{
	  sim_host_level_plus_a (host_level, (alert->risk_a / 2.5)); /* Memory update */
	  sim_container_db_update_host_level (ossim.container, ossim.dbossim, host_level); /* DB update */
	}
      else
	{
	  host_level = sim_host_level_new (alert->dst_ia, 1, (alert->risk_a / 2.5)); /* Create new host*/
	  sim_container_append_host_level (ossim.container, host_level); /* Memory addition */
	  sim_container_db_insert_host_level (ossim.container, ossim.dbossim, host_level); /* DB insert */
	}
      
      /* Update Net Levels A */
      list = nets;
      while (list)
	{
	  net = (SimNet *) list->data;
	  
	  net_level = sim_container_get_net_level_by_name (ossim.container, sim_net_get_name (net));
	  if (net_level)
	    {
	      sim_net_level_plus_a (net_level, (alert->risk_a / 2.5)); /* Memory update */
	      sim_container_db_update_net_level (ossim.container, ossim.dbossim, net_level); /* DB update */
	    }
	  else
	    {
	      net_level = sim_net_level_new (sim_net_get_name (net), 1, (alert->risk_a / 2.5));
	      sim_container_append_net_level (ossim.container, net_level); /* Memory addition */
	      sim_container_db_insert_net_level (ossim.container, ossim.dbossim, net_level); /* DB insert */
	    }
	  
	  list = list->next;
	}
      g_list_free (nets);
      
      /* Attack Responses */
      /* Updates Host Level C */
      if ((category) && (sim_category_get_id (category) == 101))
	{
	  host_level = sim_container_get_host_level_by_ia (ossim.container, alert->dst_ia);
	  if (host_level)
	    {
	      sim_host_level_plus_c (host_level, (alert->risk_c / 2.5)); /* Memory update */
	      sim_container_db_update_host_level (ossim.container, ossim.dbossim, host_level); /* DB update */
	    }
	  else
	    {
	      host_level = sim_host_level_new (alert->dst_ia, (alert->risk_c / 2.5), 1); /* Create new host*/
	      sim_container_append_host_level (ossim.container, host_level); /* Memory addition */
	      sim_container_db_insert_host_level (ossim.container, ossim.dbossim, host_level); /* DB insert */
	    }
	  
	  /* Update Net Levels C */
	  nets = sim_container_get_nets_has_ia (ossim.container, alert->dst_ia);
	  list = nets;
	  while (list)
	    {
	      net = (SimNet *) list->data;
	      
	      net_level = sim_container_get_net_level_by_name (ossim.container, sim_net_get_name (net));
	      if (net_level)
		{
		  sim_net_level_plus_c (net_level, (alert->risk_c / 2.5)); /* Memory update */
		  sim_container_db_update_net_level (ossim.container, ossim.dbossim, net_level); /* DB update */
		}
	      else
		{
		  net_level = sim_net_level_new (sim_net_get_name (net), (alert->risk_c / 2.5), 1);
		  sim_container_append_net_level (ossim.container, net_level); /* Memory addition */
		  sim_container_db_insert_net_level (ossim.container, ossim.dbossim, net_level); /* DB insert */
		}
	      
	      list = list->next;
	    }
	  g_list_free (nets);
	}
    }
}

/*
 *
 *
 *
 */
void
sim_organizer_correlation (SimOrganizer  *organizer,
			   SimAlert      *alert)
{
  SimConfig     *config;
  GList         *groups = NULL;
  GList         *lgs = NULL;
  GList         *list = NULL;
  GList		*removes = NULL;
  GList         *stickys = NULL;
  GList         *tmp = NULL;
  SimAlert      *new_alert = NULL;
  gint           id;
  gboolean       found = FALSE;
  gboolean       inserted;
  GInetAddr     *ia = NULL;

  g_return_if_fail (organizer);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));

  config = organizer->_priv->config;

  /* Match Backlogs */
  g_mutex_lock (ossim.mutex_backlogs);
  list = sim_container_get_backlogs_ul (ossim.container);
  g_log (G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "sim_organizer_correlation: backlogs %d", g_list_length (list));
  while (list)
    {
      SimDirective *backlog = (SimDirective *) list->data;
      id = sim_directive_get_id (backlog);

      inserted = FALSE;

      if (sim_directive_backlog_match_by_alert (backlog, alert))
	{
	  GNode         *rule_node;
	  SimRule       *rule_root;
	  SimRule       *rule_curr;

	  rule_node = sim_directive_get_curr_node (backlog);
	  rule_root = sim_directive_get_root_rule (backlog);
	  rule_curr = sim_directive_get_curr_rule (backlog);

	  alert->matched = TRUE;

	  /* Create New Alert */
	  new_alert = sim_alert_new ();
	  new_alert->type = SIM_ALERT_TYPE_DETECTOR;
	  new_alert->time = time (NULL);

	  if (config->sensor.ip)
	    new_alert->sensor = g_strdup (config->sensor.ip);
	  if (config->sensor.interface)
	    new_alert->interface = g_strdup (config->sensor.interface);
	  
	  new_alert->plugin_id = SIM_PLUGIN_ID_DIRECTIVE;
	  new_alert->plugin_sid = sim_directive_get_id (backlog);
	  
	  if ((ia = sim_rule_get_src_ia (rule_root))) new_alert->src_ia = gnet_inetaddr_clone (ia);
	  if ((ia = sim_rule_get_dst_ia (rule_root))) new_alert->dst_ia = gnet_inetaddr_clone (ia);
	  new_alert->src_port = sim_rule_get_src_port (rule_root);
	  new_alert->dst_port = sim_rule_get_dst_port (rule_root);
	  new_alert->protocol = sim_rule_get_protocol (rule_root);
	  new_alert->data = sim_directive_backlog_to_string (backlog);

	  new_alert->alarm = FALSE;
	  new_alert->level = alert->level;

	  alert->backlog_id = sim_directive_get_backlog_id (backlog);
	  new_alert->backlog_id = alert->backlog_id;

	  /* Rule reliability */
	  if (sim_rule_get_rel_abs (rule_curr))
	    new_alert->reliability = sim_rule_get_reliability (rule_curr);
	  else
	    new_alert->reliability = sim_rule_get_reliability_relative (rule_node);

	  /* Directive Priority */
	  new_alert->priority = sim_directive_get_priority (backlog);

	  if (!alert->id)
	    sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, alert);

	  sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, new_alert);

	  sim_container_push_alert (ossim.container, new_alert);

	  sim_container_db_update_backlog_ul (ossim.container, ossim.dbossim, backlog);
	  sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, alert);
	  sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, new_alert);

	  inserted = TRUE;

	  /* Children Rules with type MONITOR */
	  if (!G_NODE_IS_LEAF (rule_node))
	    {
	      GNode *children = rule_node->children;
	      while (children)
		{
		  SimRule *rule = children->data;
		  
		  if (rule->type == SIM_RULE_TYPE_MONITOR)
		    {
		      SimCommand *cmd = sim_command_new_from_rule (rule);
		      sim_server_push_session_plugin_command (ossim.server, 
							      SIM_SESSION_TYPE_SENSOR, 
							      sim_rule_get_plugin_id (rule),
							      cmd);
		      g_object_unref (cmd);
		    }
		  
		  children = children->next;
		}
	    } 
	  else
	    {
	      removes = g_list_append (removes, backlog);
	    }
	}

      if ((alert->match) && (!inserted))
	{
	  if (!alert->id)
	    sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, alert);

	  alert->backlog_id = sim_directive_get_backlog_id (backlog);
	  sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, alert);
	}

      if (alert->sticky)
	stickys = g_list_append (stickys, GINT_TO_POINTER (id));

      alert->matched = FALSE;
      alert->match = FALSE;

      list = list->next;
    }

  list = removes;
  while (list)
    {
      SimDirective *backlog = (SimDirective *) list->data;
      sim_container_remove_backlog_ul (ossim.container, backlog);
      sim_container_db_delete_backlog_ul (ossim.container, ossim.dbossim, backlog);
      g_object_unref (backlog);
      list = list->next;
    }
  g_list_free (removes);
  g_mutex_unlock (ossim.mutex_backlogs);


  /* Match Directives */
  g_mutex_lock (ossim.mutex_directives);
  list = sim_container_get_directives_ul (ossim.container);
  while (list)
    {
      SimDirective *directive = (SimDirective *) list->data;
      id = sim_directive_get_id (directive);

      found = FALSE;
      lgs = groups;
      while (lgs)
	{
	  SimDirectiveGroup *group = (SimDirectiveGroup *) lgs->data;

	  if ((sim_directive_group_get_sticky (group)) && (sim_directive_has_group (directive, group)))
	    {
	      found = TRUE;
	      break;
	    }

	  lgs = lgs->next;
	}

      if (found)
	{
	  list = list->next;
	  break;
	}

      found = FALSE;
      tmp = stickys;
      while (tmp) {
	gint cmp = GPOINTER_TO_INT (tmp->data);

	if (cmp == id)
	  {
	    found = TRUE;
	    break;
	  }

	tmp = tmp->next;
      }

      if (found)
	{
	  list = list->next;
	  break;
	}

      if (sim_directive_match_by_alert (directive, alert))
	{
	  SimDirective *backlog;
	  SimRule      *rule_root;
	  GNode        *node_root;

	  GTime          time_last = time (NULL);

	  if (sim_directive_get_groups (directive))
	    groups = g_list_concat (groups, g_list_copy (sim_directive_get_groups (directive)));

	  /* Create a backlog from directive */
	  backlog = sim_directive_clone (directive);
	  /* Gets the root node from backlog */
	  node_root = sim_directive_get_curr_node (backlog);
	  /* Gets the root rule from backlog */
	  rule_root = sim_directive_get_curr_rule (backlog);

	  sim_rule_set_time_last (rule_root, time_last);
	  /* Set the alert data to the rule_root */
	  sim_rule_set_alert_data (rule_root, alert);
	  
	  alert->matched = TRUE;

	  if (!alert->id)
	    sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, alert);

	  if (!G_NODE_IS_LEAF (node_root))
	    {
	      GNode *children = node_root->children;
	      while (children)
		{
		  SimRule *rule = children->data;

		  sim_rule_set_time_last (rule, time_last);
		  sim_directive_set_rule_vars (backlog, children);

		  if (rule->type == SIM_RULE_TYPE_MONITOR)
		    {
		      SimCommand *cmd = sim_command_new_from_rule (rule);
		      sim_server_push_session_plugin_command (ossim.server, 
							      SIM_SESSION_TYPE_SENSOR, 
							      sim_rule_get_plugin_id (rule),
							      cmd);
		      g_object_unref (cmd);
		    }

		  children = children->next;
		}

	      sim_container_append_backlog (ossim.container, backlog);
	      sim_container_db_insert_backlog_ul (ossim.container, ossim.dbossim, backlog);
	      sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, alert);
	      alert->backlog_id = sim_directive_get_backlog_id (backlog);
	    } 
	  else
	    {
	      sim_directive_set_matched (backlog, TRUE);

	      new_alert = sim_alert_new ();
	      new_alert->type = SIM_ALERT_TYPE_DETECTOR;
	      new_alert->alarm = FALSE;
	      new_alert->time = time (NULL);
	      new_alert->backlog_id = sim_directive_get_backlog_id (backlog);
	  
	      if (config->sensor.ip)
		new_alert->sensor = g_strdup (config->sensor.ip);
	      if (config->sensor.interface)
		new_alert->interface = g_strdup (config->sensor.interface);

	      new_alert->plugin_id = SIM_PLUGIN_ID_DIRECTIVE;
	      new_alert->plugin_sid = sim_directive_get_id (backlog);

	      if ((ia = sim_rule_get_src_ia (rule_root))) new_alert->src_ia = gnet_inetaddr_clone (ia);
	      if ((ia = sim_rule_get_dst_ia (rule_root))) new_alert->dst_ia = gnet_inetaddr_clone (ia);
	      new_alert->src_port = sim_rule_get_src_port (rule_root);
	      new_alert->dst_port = sim_rule_get_dst_port (rule_root);
	      new_alert->protocol = sim_rule_get_protocol (rule_root);
	      new_alert->data = sim_directive_backlog_to_string (backlog);
	      
	      /* Rule reliability */
	      if (sim_rule_get_rel_abs (rule_root))
		new_alert->reliability = sim_rule_get_reliability (rule_root);
	      else
		new_alert->reliability = sim_rule_get_reliability_relative (node_root);

	      /* Directive Priority */
	      new_alert->priority = sim_directive_get_priority (backlog);

	      sim_container_db_insert_alert_ul (ossim.container, ossim.dbossim, new_alert);

	      sim_container_push_alert (ossim.container, new_alert);

	      sim_container_db_insert_backlog_ul (ossim.container, ossim.dbossim, backlog);
	      sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, alert);
	      sim_container_db_insert_backlog_alert_ul (ossim.container, ossim.dbossim, backlog, new_alert);
	      alert->backlog_id = sim_directive_get_backlog_id (backlog);

	      g_object_unref (backlog);
	    }
	}
      alert->matched = FALSE;
      alert->match = FALSE;

      list = list->next;
    }
  g_mutex_unlock (ossim.mutex_directives);

  g_list_free (stickys);
  g_list_free (groups);
}

/*
 *
 *
 *
 *
 */
void
sim_organizer_snort_ossim_event_insert (SimDatabase  *db_snort,
					SimAlert     *alert,
					gint          sid,
					gulong          cid)
{
  gchar         *insert;
  gint           c;
  gint           a;

  g_return_if_fail (db_snort);
  g_return_if_fail (SIM_IS_DATABASE (db_snort));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));
  g_return_if_fail (sid > 0);
  g_return_if_fail (cid > 0);

  alert->snort_sid = sid;
  alert->snort_cid = cid;

  c = rint (alert->risk_c);
  a = rint (alert->risk_a);

  /* insert OSSIM Alert */
  insert = g_strdup_printf ("INSERT INTO ossim_event (sid, cid, type, priority, reliability, asset_src, asset_dst, risk_c, risk_a) "
			    "VALUES (%u, %u, %u, %u, %u, %u, %u, %u, %u)", sid, cid,
			    (alert->alarm) ? 2 : 1,
			    alert->priority, alert->reliability,
			    alert->asset_src, alert->asset_dst, c, a);

  sim_database_execute_no_query (db_snort, insert);
  g_free (insert);
}

/*
 *
 *
 *
 */
gint
sim_organizer_snort_sersor_get_sid (SimDatabase  *db_snort,
				    gchar        *hostname,
				    gchar        *interface,
				    gchar        *plugin_name)
{
  GdaDataModel  *dm;
  GdaValue      *value;
  gint64         sid;
  gchar         *query;
  gchar         *insert;
  gint           row;
  
  g_return_val_if_fail (db_snort, 0);
  g_return_val_if_fail (SIM_IS_DATABASE (db_snort), 0);
  g_return_val_if_fail (hostname, 0);
  g_return_val_if_fail (interface, 0);

  /* SID */
  if (plugin_name)
    query = g_strdup_printf ("SELECT sid FROM sensor WHERE hostname = '%s-%s' AND interface = '%s'", 
			   hostname, plugin_name, interface);
  else
    query = g_strdup_printf ("SELECT sid FROM sensor WHERE hostname = '%s' AND interface = '%s'", 
			   hostname, interface);

  dm = sim_database_execute_single_command (db_snort, query);
  if (dm)
    {
      if (gda_data_model_get_n_rows (dm))
	{
	  value = (GdaValue *) gda_data_model_get_value_at (dm, 0, 0);
	  sid = gda_value_get_integer (value);
	}
      else
	{
	  if (plugin_name)
	    insert = g_strdup_printf ("INSERT INTO sensor (hostname, interface, encoding, last_cid) "
				      "VALUES ('%s-%s', '%s', 2, 0)", hostname, plugin_name, interface);
	  else
	    insert = g_strdup_printf ("INSERT INTO sensor (hostname, interface, detail, encoding, last_cid) "
				      "VALUES ('%s', '%s', 1, 0, 0)", hostname, interface);

	  sim_database_execute_no_query (db_snort, insert);
	  g_free (insert);

	  sid = sim_organizer_snort_sersor_get_sid (db_snort, hostname, interface, plugin_name);
	}

      g_object_unref(dm);
    }
  else
    {
      g_message ("SENSOR SID DATA MODEL ERROR");
    }
  g_free (query);

  return sid;
}

/*
 *
 *
 *
 *
 */
gint
sim_organizer_snort_event_get_max_cid (SimDatabase  *db_snort,
					 gint          sid)
{
  GdaDataModel  *dm;
  GdaValue      *value;
  gint           last_cid = 0;
  gchar         *query;
  gint           row;

  g_return_val_if_fail (db_snort, 0);
  g_return_val_if_fail (SIM_IS_DATABASE (db_snort), 0);
  g_return_val_if_fail (sid > 0, 0);

  /* CID */
  query = g_strdup_printf ("SELECT max(cid) FROM event WHERE sid = %d", sid);
  dm = sim_database_execute_single_command (db_snort, query);
  if (dm)
    {
      for (row = 0; row < gda_data_model_get_n_rows (dm); row++)
	{
	  value = (GdaValue *) gda_data_model_get_value_at (dm, 0, row);
	  if (!gda_value_is_null (value))
	    last_cid = gda_value_get_integer (value);
	}
      
      g_object_unref(dm);
    }
  else
    {
      g_message ("LAST CID DATA MODEL ERROR");
    }
  g_free (query);

  return last_cid;
}

/*
 *
 *
 *
 *
 */
gint
sim_organizer_snort_signature_get_id (SimDatabase  *db_snort,
				      gchar        *name)
{
  GdaDataModel  *dm;
  GdaValue      *value;
  gint           sig_id;
  gchar         *query;
  gchar         *insert;
  gint           row;
  gint           ret;

  g_return_val_if_fail (db_snort, 0);
  g_return_val_if_fail (SIM_IS_DATABASE (db_snort), 0);
  g_return_val_if_fail (name, 0);

  /* SID */
  query = g_strdup_printf ("SELECT sig_id FROM signature WHERE sig_name = '%s'", name);
  dm = sim_database_execute_single_command (db_snort, query);
  if (dm)
    {
      if (gda_data_model_get_n_rows (dm))
	{
	  value = (GdaValue *) gda_data_model_get_value_at (dm, 0, 0);
	  sig_id = gda_value_get_integer (value);
	}
      else
	{
	  insert = g_strdup_printf ("INSERT INTO signature (sig_name, sig_class_id) "
				    "VALUES ('%s', 0)", name);

	  ret = sim_database_execute_no_query (db_snort, insert);
	  g_free (insert);

	  if (ret < 0)
	      g_critical ("ERROR: CANT INSERT INTO SNORT DB");

	  sig_id = sim_organizer_snort_signature_get_id (db_snort, name);
	}
      
      g_object_unref(dm);
    }
  else
    {
      g_message ("SIG ID DATA MODEL ERROR");
    }
  g_free (query);

  return sig_id;  
}

/*
 *
 *
 *
 */
void
sim_organizer_snort_event_insert (SimDatabase  *db_snort,
				  SimAlert     *alert,
				  gint          sid,
				  gulong        cid,
				  gint          sig_id)
{
  gchar timestamp[TIMEBUF_SIZE];
  gchar *query;

  g_return_if_fail (db_snort);
  g_return_if_fail (SIM_IS_DATABASE (db_snort));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));
  g_return_if_fail (sid > 0);
  g_return_if_fail (cid > 0);
  g_return_if_fail (sig_id > 0);

  strftime (timestamp, TIMEBUF_SIZE, "%Y-%m-%d %H:%M:%S", localtime ((time_t *) &alert->time));

  query = g_strdup_printf ("INSERT INTO event (sid, cid, signature, timestamp) "
			   "VALUES (%u, %u, %u, '%s')",
			   sid, cid, sig_id, timestamp);
  sim_database_execute_no_query (db_snort, query);
  g_free (query);

  query = g_strdup_printf ("INSERT INTO iphdr (sid, cid, ip_src, ip_dst, ip_proto) "
			   "VALUES (%u, %u, %lu, %lu, %d)",
			   sid, cid,
			   (alert->src_ia) ? sim_inetaddr_ntohl (alert->src_ia) : -1,
			   (alert->dst_ia) ? sim_inetaddr_ntohl (alert->dst_ia) : -1,
			   alert->protocol);
  sim_database_execute_no_query (db_snort, query);
  g_free (query);

  switch (alert->protocol)
    {
    case SIM_PROTOCOL_TYPE_ICMP:
      query = g_strdup_printf ("INSERT INTO icmphdr (sid, cid, icmp_type, icmp_code) "
			       "VALUES (%u, %u, 8, 0)",
			       sid, cid);
      sim_database_execute_no_query (db_snort, query);
      g_free (query);
      break;
    case SIM_PROTOCOL_TYPE_TCP:
      query = g_strdup_printf ("INSERT INTO tcphdr (sid, cid, tcp_sport, tcp_dport, tcp_flags) "
			       "VALUES (%u, %u, %d, %d, 24)",
			       sid, cid, alert->src_port, alert->dst_port);
      sim_database_execute_no_query (db_snort, query);
      g_free (query);
      break;
    case SIM_PROTOCOL_TYPE_UDP:
      query = g_strdup_printf ("INSERT INTO udphdr (sid, cid, udp_sport, udp_dport) "
			       "VALUES (%u, %u, %d, %d)",
			       sid, cid, alert->src_port, alert->dst_port);
      sim_database_execute_no_query (db_snort, query);
      g_free (query);
      break;
    default:
      break;
    }

  if (alert->data)
    {
      query = g_strdup_printf ("INSERT INTO data (sid, cid, data_payload) "
			       "VALUES (%u, %u, '%s')",
			       sid, cid, alert->data);
      sim_database_execute_no_query (db_snort, query);
      g_free (query);
    }

  sim_organizer_snort_ossim_event_insert (db_snort, alert, sid, cid);
}

/*
 *
 *
 *
 */
void
sim_organizer_snort_event_get_cid_from_alert (SimDatabase  *db_snort,
					      SimAlert     *alert,
					      gint          sid,
					      gint          sig_id)
{
  GdaDataModel  *dm;
  GdaValue      *value;
  gchar          timestamp[TIMEBUF_SIZE];
  GString       *select;
  GString       *where;
  gint           row;
  gulong         cid;
  gchar         *src_ip;
  gchar         *dst_ip;

  g_return_if_fail (db_snort);
  g_return_if_fail (SIM_IS_DATABASE (db_snort));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));
  g_return_if_fail (sid > 0);
  g_return_if_fail (sig_id > 0);

  strftime (timestamp, TIMEBUF_SIZE, "%Y-%m-%d %H:%M:%S", localtime ((time_t *) &alert->time));

  select = g_string_new ("SELECT event.cid FROM event LEFT JOIN iphdr ON (event.sid = iphdr.sid AND event.cid = iphdr.cid)");
  where = g_string_new (" WHERE");

  g_string_append_printf (where, " event.sid = %u", sid);
  g_string_append_printf (where, " AND event.signature = %u", sig_id);
  g_string_append_printf (where, " AND event.timestamp = '%s'", timestamp);

  if (alert->src_ia)
    g_string_append_printf (where, " AND ip_src = %lu", sim_inetaddr_ntohl (alert->src_ia));
  if (alert->dst_ia)
    g_string_append_printf (where, " AND ip_dst = %lu", sim_inetaddr_ntohl (alert->dst_ia));
  
  g_string_append_printf (where, " AND ip_proto = %d", alert->protocol);

  switch (alert->protocol)
    {
    case SIM_PROTOCOL_TYPE_ICMP:
      break;
    case SIM_PROTOCOL_TYPE_TCP:
      g_string_append (select, " LEFT JOIN tcphdr ON (event.sid = tcphdr.sid AND event.cid = tcphdr.cid)");

      if (alert->src_port)
	g_string_append_printf (where, " AND tcp_sport = %d", alert->src_port);
      if (alert->dst_port)
	g_string_append_printf (where, " AND tcp_dport = %d", alert->dst_port);
      break;
    case SIM_PROTOCOL_TYPE_UDP:
      g_string_append (select, " LEFT JOIN udphdr ON (event.sid = udphdr.sid AND event.cid = udphdr.cid)");

      if (alert->src_port)
	g_string_append_printf (where, " AND udp_sport = %d ", alert->src_port);
      if (alert->dst_port)
	g_string_append_printf (where, " AND udp_dport = %d ", alert->dst_port);
      break;
    default:
      break;
    }

  g_string_append (select, where->str);

  g_string_free (where, TRUE);

  dm = sim_database_execute_single_command (db_snort, select->str);
  if (dm)
    {
      for (row = 0; row < gda_data_model_get_n_rows (dm); row++)
	{
	  value = (GdaValue *) gda_data_model_get_value_at (dm, 0, row);
	  cid = gda_value_get_integer (value);
	  sim_organizer_snort_ossim_event_insert (db_snort, alert, sid, cid);
	}

      g_object_unref(dm);
    }
  else
    {
      g_message ("ALERTS ID DATA MODEL ERROR");
    }

  g_string_free (select, TRUE);
}

/*
 *
 *
 *
 */
void
sim_organizer_snort (SimOrganizer	*organizer,
		     SimAlert		*alert)
{
  SimPlugin	*plugin;
  SimPluginSid	*plugin_sid;
  gint64	 last_id;
  gchar		*query;
  gint		 sid;
  gulong	 cid;
  gint		 sig_id;
  GList		*alerts = NULL;
  GList		*list = NULL;

  g_return_if_fail (organizer);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));
  g_return_if_fail (alert->sensor);
  g_return_if_fail (alert->interface);

  if (alert->snort_sid && alert->snort_cid)
    {
      sim_organizer_snort_ossim_event_insert (ossim.dbsnort,
					      alert,
					      alert->snort_sid,
					      alert->snort_cid);
      return;
    }

  plugin_sid = sim_container_get_plugin_sid_by_pky (ossim.container, alert->plugin_id, alert->plugin_sid);
  if (!plugin_sid)
    {
      g_message ("sim_organizer_snort: Error Plugin %d, PlugginSid %d", alert->plugin_id, alert->plugin_sid);
      return;
    }
  sig_id = sim_organizer_snort_signature_get_id (ossim.dbsnort,
						 sim_plugin_sid_get_name (plugin_sid));

  /* Alerts SNORT */
  if ((alert->plugin_id >= 1001) && (alert->plugin_id < 1500))
    {
      sid = sim_organizer_snort_sersor_get_sid (ossim.dbsnort,
						alert->sensor,
						alert->interface,
						NULL);
      sim_organizer_snort_event_get_cid_from_alert (ossim.dbsnort,
						    alert, sid, sig_id);
    }
  else /* Others Alerts */
    {
      plugin = sim_container_get_plugin_by_id (ossim.container, alert->plugin_id);
      sid = sim_organizer_snort_sersor_get_sid (ossim.dbsnort,
						alert->sensor,
						alert->interface,
						sim_plugin_get_name (plugin));
      cid = sim_organizer_snort_event_get_max_cid (ossim.dbsnort,
						   sid);
      sim_organizer_snort_event_insert (ossim.dbsnort,
					alert, sid, ++cid, sig_id);
    }
}

/*
 * 
 *
 * Insert rrd anomalies into separate tables
 */
void
sim_organizer_rrd (SimOrganizer  *organizer,
		     SimAlert      *alert)
{
  SimPluginSid  *plugin_sid;
  gchar         *insert;
  gchar         *name;
  gchar         *plugin_sid_name;
  gchar timestamp[TIMEBUF_SIZE];

  g_return_if_fail (organizer);
  g_return_if_fail (SIM_IS_ORGANIZER (organizer));
  g_return_if_fail (alert);
  g_return_if_fail (SIM_IS_ALERT (alert));
  g_return_if_fail (alert->sensor);
  g_return_if_fail (alert->interface);

  if (alert->plugin_id != 1508 ) // Return if not rrd_anomaly
    return;

  plugin_sid = sim_container_get_plugin_sid_by_pky (ossim.container, alert->plugin_id, alert->plugin_sid);
  if (!plugin_sid)
    {
      g_message ("sim_organizer_rrd: Error Plugin %d, PlugginSid %d", alert->plugin_id, alert->plugin_sid);
      return;
    }

  strftime (timestamp, TIMEBUF_SIZE, "%Y-%m-%d %H:%M:%S", localtime ((time_t *) &alert->time));
  
  name = gnet_inetaddr_get_canonical_name(alert->src_ia);
  plugin_sid_name = sim_plugin_sid_get_name(plugin_sid);
  insert = g_strdup_printf("INSERT INTO rrd_anomalies(ip, what, anomaly_time, range) VALUES ('%s', '%s', '%s', '0')", name, plugin_sid_name, timestamp);
  sim_database_execute_no_query (ossim.dbossim, insert);
  g_free(insert);
  g_free(name);
}
